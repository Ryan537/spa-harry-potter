import { Component } from '@angular/core';

@Component({
  selector: 'app-characters-detail',
  standalone: true,
  imports: [],
  templateUrl: './characters-detail.component.html',
  styleUrl: './characters-detail.component.css'
})
export class CharactersDetailComponent {

}
