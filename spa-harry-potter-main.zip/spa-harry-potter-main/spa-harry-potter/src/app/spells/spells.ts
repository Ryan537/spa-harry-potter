export type Spells = Spells1[]

export interface Spells1 {
  id: string
  name: string
  description: string
}